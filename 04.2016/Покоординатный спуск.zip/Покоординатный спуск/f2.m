function y=f2(a1,a2)
    y = a1+4*a2+a1*a2-2*a1^2-2*a2^2;